import Link from "next/link";
import { MessageCircleQuestion, LibraryBig, Sparkles } from "lucide-react";
import BrandMark from "@/components/BrandMark";
import YoutubeIcon from "@/components/YoutubeIcon";
import { CHANNEL } from "@/db/schema";

export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/5 bg-night/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" className="group flex items-center gap-3">
          <span className="transition-transform duration-500 group-hover:rotate-45">
            <BrandMark size={36} />
          </span>
          <span className="leading-tight">
            <span className="font-display block text-xl font-bold gold-text">
              مسلم وبس
            </span>
            <span className="block text-[10px] tracking-wide text-ash">
              ذكاء اصطناعي من نصوص القناة
            </span>
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2 text-sm">
          <Link
            href="/ask"
            className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sand transition-colors hover:bg-white/5 hover:text-goldbright"
          >
            <MessageCircleQuestion size={16} />
            <span className="hidden sm:inline">اسأل الذكاء</span>
          </Link>
          <Link
            href="/library"
            className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sand transition-colors hover:bg-white/5 hover:text-goldbright"
          >
            <LibraryBig size={16} />
            <span className="hidden sm:inline">المكتبة</span>
          </Link>
          <a
            href={CHANNEL.url}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sand transition-colors hover:bg-white/5 hover:text-goldbright"
          >
            <YoutubeIcon size={16} />
            <span className="hidden md:inline">القناة</span>
          </a>
          <Link
            href="/ask"
            className="mr-1 hidden items-center gap-1.5 rounded-full bg-gradient-to-l from-golddeep via-gold to-goldbright px-4 py-2 font-semibold text-night shadow-[0_6px_24px_rgba(200,162,78,0.35)] transition-transform hover:scale-[1.03] sm:flex"
          >
            <Sparkles size={15} />
            جرّب الآن
          </Link>
        </nav>
      </div>
    </header>
  );
}
