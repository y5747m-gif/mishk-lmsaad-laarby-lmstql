"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Search, ExternalLink, ScanText, MessageCircleQuestion, Layers } from "lucide-react";
import YoutubeIcon from "@/components/YoutubeIcon";

type VideoRow = {
  videoId: string;
  title: string;
  description: string;
  url: string;
  thumbnail: string;
  publishedAt: string | null;
  views: number;
  hasTranscript: boolean;
  wordCount: number;
  chunks: number;
};

export default function LibraryBrowser() {
  const [videos, setVideos] = useState<VideoRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [onlyTranscribed, setOnlyTranscribed] = useState(false);
  const fmt = useMemo(() => new Intl.NumberFormat("ar-EG"), []);
  const dfmt = useMemo(
    () =>
      new Intl.DateTimeFormat("ar", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
    [],
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/videos", { cache: "no-store" });
        const data = (await res.json()) as {
          ok?: boolean;
          videos?: VideoRow[];
          error?: string;
        };
        if (!cancelled) {
          if (data.ok) setVideos(data.videos ?? []);
          else setError(data.error ?? "تعذّر التحميل");
        }
      } catch {
        if (!cancelled) setError("تعذّر الاتصال بالخادم");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const filtered = videos.filter((v) => {
    if (onlyTranscribed && !v.hasTranscript) return false;
    if (!q.trim()) return true;
    return `${v.title} ${v.description}`.includes(q.trim());
  });

  return (
    <div className="mt-10">
      {/* أدوات البحث */}
      <div className="flex flex-col items-stretch justify-between gap-3 sm:flex-row sm:items-center">
        <div className="gold-ring flex flex-1 items-center gap-2 rounded-2xl px-4 py-2.5">
          <Search size={16} className="shrink-0 text-gold" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث في عناوين الفيديوهات ووصفها…"
            className="w-full bg-transparent text-sm text-ivory outline-none placeholder:text-ash/60"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOnlyTranscribed((v) => !v)}
            className={`flex items-center gap-1.5 rounded-full px-4 py-2.5 text-xs font-bold transition-all ${
              onlyTranscribed
                ? "bg-jade/15 text-jade border border-jade/40"
                : "glass text-sand hover:border-jade/30"
            }`}
          >
            <ScanText size={14} />
            النصوص المستخرجة فقط
          </button>
          <span className="rounded-full glass px-3.5 py-2.5 text-xs text-ash">
            {fmt.format(filtered.length)} فيديو
          </span>
        </div>
      </div>

      {/* المحتوى */}
      {loading ? (
        <div className="mt-16 grid place-items-center">
          <div className="typing-dots flex items-center gap-1.5">
            <span /> <span /> <span />
          </div>
        </div>
      ) : error ? (
        <p className="mt-16 text-center text-sm text-ash">{error}</p>
      ) : filtered.length === 0 ? (
        <div className="mt-16 text-center">
          <p className="text-sm text-ash">
            لا توجد نتائج مطابقة — جرّب كلمة أخرى أو حدّث قاعدة المعرفة من صفحة الأسئلة.
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((v, i) => (
            <motion.article
              key={v.videoId}
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.06, 0.6), duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              className="group flex flex-col overflow-hidden rounded-3xl glass transition-all duration-300 hover:-translate-y-1.5 hover:border-gold/30"
            >
              <div className="relative aspect-video overflow-hidden">
                <Image
                  src={v.thumbnail}
                  alt={v.title}
                  fill
                  sizes="(max-width: 640px) 100vw, 360px"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  unoptimized
                />
                <div className="absolute inset-0 bg-gradient-to-t from-night/90 via-transparent to-transparent" />
                {v.hasTranscript && (
                  <span className="absolute bottom-2.5 right-2.5 flex items-center gap-1 rounded-full bg-jade/90 px-2.5 py-1 text-[10px] font-bold text-night">
                    <ScanText size={11} />
                    نص مستخرج
                  </span>
                )}
              </div>

              <div className="flex flex-1 flex-col p-5">
                <h3 className="line-clamp-2 min-h-[3.4rem] text-sm font-bold leading-7 text-ivory">
                  {v.title}
                </h3>
                {v.description && (
                  <p className="mt-2 line-clamp-2 text-xs leading-6 text-ash">
                    {v.description}
                  </p>
                )}
                <div className="mt-3 flex flex-wrap items-center gap-3 text-[10.5px] text-ash/80">
                  {v.publishedAt && (
                    <span>{dfmt.format(new Date(v.publishedAt))}</span>
                  )}
                  {v.views > 0 && <span>{fmt.format(v.views)} مشاهدة</span>}
                  {v.wordCount > 0 && (
                    <span className="flex items-center gap-1 text-jade">
                      <Layers size={11} />
                      {fmt.format(v.wordCount)} كلمة
                    </span>
                  )}
                </div>

                <div className="mt-4 flex items-center gap-2 border-t border-white/6 pt-4">
                  <a
                    href={v.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-l from-golddeep via-gold to-goldbright px-3 py-2 text-xs font-bold text-night transition-transform hover:scale-[1.02]"
                  >
                    <YoutubeIcon size={14} />
                    مشاهدة
                  </a>
                  <Link
                    href={`/ask?q=${encodeURIComponent(`ما الذي قيل في: ${v.title.slice(0, 70)}؟`)}`}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl glass px-3 py-2 text-xs font-bold text-sand transition-all hover:border-jade/35 hover:text-mint"
                  >
                    <MessageCircleQuestion size={14} />
                    اسأل عنه
                  </Link>
                  <a
                    href={v.url}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="فتح في يوتيوب"
                    className="grid h-9 w-9 place-items-center rounded-xl glass text-ash transition-colors hover:text-goldbright"
                  >
                    <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      )}
    </div>
  );
}
