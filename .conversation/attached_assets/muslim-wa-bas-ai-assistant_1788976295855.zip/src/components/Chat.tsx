"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import {
  SendHorizonal,
  RefreshCw,
  Sparkles,
  CircleAlert,
  ExternalLink,
  ScrollText,
  BadgeCheck,
  User,
} from "lucide-react";
import BrandMark from "@/components/BrandMark";
import YoutubeIcon from "@/components/YoutubeIcon";

/* ──────────────────────── الأنواع ──────────────────────── */
type Source = {
  videoId: string;
  title: string;
  url: string;
  thumbnail: string;
  snippet: string;
  relevance: number;
};

type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: Source[];
  confidence?: number;
  kind?: string;
  streaming?: boolean;
};

const SUGGESTIONS = [
  "ما عقوبة الربا في الإسلام؟",
  "ما أهمية الدعوة إلى الله وآداب الداعي؟",
  "ما حكم شتم الأب والأم؟",
  "ماذا جاء في تفسير سورة المدثر؟",
  "ما مختصر رحلة الإنسان من البداية إلى النهاية؟",
  "ما نتائج الدعوة إلى الله في الدنيا والآخرة؟",
];

const TIPS = [
  "أستخرج النصوص من فيديوهات القناة…",
  "أطابق سؤالك مع المقاطع المعرفية…",
  "أرتّب المصادر الموثقة…",
  "أُحضّر صياغة الجواب…",
];

/* ───────────────────── عارض نص عربي مُنسّق ───────────────────── */
function RichLine({ line }: { line: string }) {
  if (line.startsWith("«") && line.endsWith("»")) {
    return <p className="excerpt text-[15px] my-4">{line.slice(1, -1)}</p>;
  }
  if (line.startsWith("• ")) {
    return (
      <p className="my-2 flex items-start gap-2 text-[15px] leading-8 text-ivory/90">
        <span className="mt-3 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
        <RenderBold text={line.slice(2)} />
      </p>
    );
  }
  return (
    <p className="my-2 text-[15px] leading-8 text-ivory/90">
      <RenderBold text={line} />
    </p>
  );
}

function RenderBold({ text }: { text: string }) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean);
  return (
    <>
      {parts.map((p, i) =>
        p.startsWith("**") && p.endsWith("**") ? (
          <strong key={i} className="font-bold text-goldbright">
            {p.slice(2, -2)}
          </strong>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

function confidenceMeta(c?: number) {
  if (c === undefined) return null;
  if (c >= 0.7) return { label: "ثقة عالية", cls: "text-jade border-jade/30 bg-jade/10" };
  if (c >= 0.4) return { label: "ثقة جيدة", cls: "text-goldbright border-gold/30 bg-gold/10" };
  return { label: "ارتباط محدود", cls: "text-ash border-white/15 bg-white/5" };
}

/* ───────────────────── بطاقة مصدر الفيديو ───────────────────── */
function SourceCard({ s, index }: { s: Source; index: number }) {
  return (
    <motion.a
      href={s.url}
      target="_blank"
      rel="noreferrer"
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="group block overflow-hidden rounded-2xl glass transition-all duration-300 hover:-translate-y-1 hover:border-gold/35"
    >
      <div className="relative aspect-video w-full overflow-hidden">
        <Image
          src={s.thumbnail}
          alt={s.title}
          fill
          sizes="(max-width: 640px) 90vw, 360px"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
          unoptimized
        />
        <div className="absolute inset-0 bg-gradient-to-t from-night/95 via-night/25 to-transparent" />
        <div className="absolute bottom-2 right-2 flex items-center gap-1.5 rounded-full bg-night/80 px-2.5 py-1 text-[10px] font-bold text-goldbright backdrop-blur">
          <YoutubeIcon size={12} />
          مشاهدة الفيديو
        </div>
        <div className="absolute right-0 top-0 h-[3px] bg-gradient-to-l from-goldbright to-jade transition-all"
          style={{ width: `${Math.round(s.relevance * 100)}%` }}
        />
      </div>
      <div className="p-4">
        <h4 className="line-clamp-2 min-h-[3.2rem] text-sm font-bold leading-7 text-ivory">
          {s.title}
        </h4>
        <p className="mt-2 line-clamp-3 text-[12.5px] leading-6 text-ash">{s.snippet}</p>
        <div className="mt-3 flex items-center justify-between text-[10.5px]">
          <span className="flex items-center gap-1 text-jade">
            <BadgeCheck size={13} />
            نسبة الارتباط {Math.round(s.relevance * 100)}٪
          </span>
          <span className="flex items-center gap-1 text-sand opacity-70 transition-opacity group-hover:opacity-100">
            يوتيوب <ExternalLink size={11} />
          </span>
        </div>
      </div>
    </motion.a>
  );
}

/* ───────────────────── فقاعة رسالة ───────────────────── */
function Bubble({ m }: { m: Msg }) {
  const conf = confidenceMeta(m.confidence);
  if (m.role === "user") {
    return (
      <div className="flex justify-start">
        <div className="flex max-w-[85%] items-end gap-2.5 sm:max-w-[70%]">
          <span className="mb-1 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-jade/30 bg-jade/10">
            <User size={14} className="text-jade" />
          </span>
          <div className="rounded-3xl rounded-tr-md border border-jade/25 bg-gradient-to-bl from-pine/80 to-moss/60 px-5 py-3.5 text-[15px] leading-8 text-ivory shadow-lg">
            {m.content}
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="flex justify-end">
      <div className="w-full max-w-full">
        <div className="mb-2 flex items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-xs text-ash">
            <BrandMark size={22} />
            <span className="font-bold text-goldbright">مسلم وبس</span>
            يجيب من نصوص القناة
          </span>
          {conf && !m.streaming && (
            <span className={`rounded-full border px-2.5 py-0.5 text-[10px] font-bold ${conf.cls}`}>
              {conf.label}
            </span>
          )}
        </div>
        <div className="rounded-3xl rounded-tl-md glass-strong px-5 py-4 shadow-xl sm:px-7 sm:py-5">
          {m.content.split("\n").map((line, i) =>
            line.trim() === "" ? (
              <span key={i} className="block h-1" />
            ) : (
              <RichLine key={i} line={line} />
            ),
          )}
          {m.streaming && <span className="caret" />}
        </div>
        {m.sources && m.sources.length > 0 && !m.streaming && (
          <div className="mt-4">
            <p className="mb-3 flex items-center gap-2 text-xs font-bold tracking-wide text-sand">
              <ScrollText size={14} className="text-gold" />
              الفيديوهات الموثقة المرتبطة بسؤالك ({m.sources.length})
            </p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {m.sources.map((s, i) => (
                <SourceCard key={`${s.videoId}-${i}`} s={s} index={i} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ───────────────────── المكوّن الرئيسي ───────────────────── */
export default function Chat() {
  const params = useSearchParams();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [tip, setTip] = useState(0);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [syncState, setSyncState] = useState<"idle" | "running" | "done">("idle");
  const [syncMsg, setSyncMsg] = useState("");

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const askedParam = useRef(false);

  const scrollDown = useCallback(() => {
    requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }, []);

  /* كشف تدريجي للنص (آلة كاتبة) */
  const revealAssistant = useCallback(
    (full: string, meta: Partial<Msg>) => {
      const id = crypto.randomUUID();
      setMessages((prev) => [
        ...prev,
        { id, role: "assistant", content: "", streaming: true, ...meta },
      ]);
      let pos = 0;
      const tick = () => {
        pos = Math.min(full.length, pos + 3 + Math.floor(Math.random() * 4));
        const current = full.slice(0, pos);
        setMessages((prev) =>
          prev.map((x) => (x.id === id ? { ...x, content: current } : x)),
        );
        scrollDown();
        if (pos < full.length) {
          timers.current.push(setTimeout(tick, 13));
        } else {
          setMessages((prev) =>
            prev.map((x) => (x.id === id ? { ...x, streaming: false } : x)),
          );
          scrollDown();
        }
      };
      timers.current.push(setTimeout(tick, 120));
    },
    [scrollDown],
  );

  const ask = useCallback(
    async (text: string) => {
      const q = text.trim();
      if (!q || busy) return;
      setBusy(true);
      setInput("");
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "user", content: q },
      ]);
      scrollDown();

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: q, conversationId }),
        });
        const data = (await res.json()) as {
          ok?: boolean;
          conversationId?: number;
          kind?: string;
          answer?: string;
          sources?: Source[];
          confidence?: number;
          error?: string;
        };
        if (!res.ok || !data.ok) throw new Error(data.error || "خطأ غير متوقع");
        if (data.conversationId) {
          setConversationId(data.conversationId);
          try {
            localStorage.setItem("mw_conversation", String(data.conversationId));
          } catch { /* خاص */ }
        }
        revealAssistant(data.answer ?? "", {
          sources: data.sources ?? [],
          confidence: data.confidence,
          kind: data.kind,
        });
      } catch (e) {
        revealAssistant(
          `**تعذّر توليد الإجابة الآن.**\n\n${e instanceof Error ? e.message : "خطأ"} — حاول مرة أخرى بعد لحظات.`,
          { confidence: 0 },
        );
      } finally {
        setBusy(false);
        inputRef.current?.focus();
      }
    },
    [busy, conversationId, revealAssistant, scrollDown],
  );

  /* إرسال تلقائي من ?q= */
  useEffect(() => {
    const q = params.get("q");
    if (q && !askedParam.current) {
      askedParam.current = true;
      void ask(q);
    }
  }, [params, ask]);

  /* استرجاع محادثة سابقة */
  useEffect(() => {
    try {
      const saved = localStorage.getItem("mw_conversation");
      if (saved) setConversationId(Number(saved) || null);
    } catch { /* خاص */ }
    return () => {
      timers.current.forEach(clearTimeout);
    };
  }, []);

  /* تدوير نصائح الانتظار */
  useEffect(() => {
    if (!busy) return;
    const i = setInterval(() => setTip((t) => (t + 1) % TIPS.length), 1800);
    return () => clearInterval(i);
  }, [busy]);

  const runSync = async () => {
    setSyncState("running");
    setSyncMsg("جارٍ مزامنة القناة مع قاعدة البيانات…");
    try {
      const res = await fetch("/api/sync?force=1", { method: "POST" });
      const data = (await res.json()) as {
        ok?: boolean;
        videosUpserted?: number;
        transcriptsFetched?: number;
        chunksCreated?: number;
        error?: string;
      };
      if (data.ok) {
        setSyncState("done");
        setSyncMsg(
          `اكتملت المزامنة: ${data.videosUpserted ?? 0} فيديو • ${data.transcriptsFetched ?? 0} نص جديد • ${data.chunksCreated ?? 0} مقطع`,
        );
      } else {
        setSyncState("idle");
        setSyncMsg(data.error ?? "لم تكتمل المزامنة");
      }
    } catch {
      setSyncState("idle");
      setSyncMsg("تعذّرت المزامنة — تحقق من الاتصال");
    }
    setTimeout(() => setSyncState("idle"), 9000);
  };

  const empty = messages.length === 0;

  return (
    <div className="mx-auto flex h-[calc(100vh-4rem)] max-w-5xl flex-col px-3 sm:px-5">
      {/* شريط أدوات */}
      <div className="flex items-center justify-between gap-3 py-3">
        <p className="flex min-w-0 items-center gap-2 truncate text-xs text-ash">
          <Sparkles size={14} className="shrink-0 text-gold" />
          <span className="truncate">
            {syncState === "idle" && !syncMsg
              ? "اسأل في أي موضوع ديني تناولته القناة"
              : syncMsg}
          </span>
        </p>
        <button
          onClick={runSync}
          disabled={syncState === "running"}
          className="flex shrink-0 items-center gap-1.5 rounded-full glass px-3.5 py-1.5 text-[11px] font-bold text-sand transition-all hover:border-gold/30 hover:text-goldbright disabled:opacity-60"
        >
          <RefreshCw size={13} className={syncState === "running" ? "animate-spin" : ""} />
          {syncState === "running" ? "يُزامِن…" : "تحديث قاعدة المعرفة"}
        </button>
      </div>

      {/* منطقة الرسائل */}
      <div
        ref={scrollRef}
        className="relative flex-1 space-y-7 overflow-y-auto scroll-smooth rounded-3xl border border-white/6 bg-abyss/40 p-4 sm:p-6"
      >
        {empty && (
          <div className="flex h-full flex-col items-center justify-center px-4 py-10 text-center">
            <div className="relative mb-6">
              <div className="absolute inset-0 -m-6 rounded-full bg-[radial-gradient(circle,rgba(233,205,133,0.12),transparent_70%)]" />
              <BrandMark size={72} />
            </div>
            <h2 className="font-display text-3xl font-bold gold-text sm:text-4xl">
              مسلم وبس
            </h2>
            <p className="mt-3 max-w-lg text-sm leading-8 text-ash">
              أجيب على أسئلتك الدينية من النصوص المستخرجة حرفيًا من فيديوهات قناة
              «تعلم دينك لتنجو وتسعد»، وأرفق لك روابط الفيديوهات الموثقة.
            </p>
            <div className="mt-8 grid w-full max-w-2xl gap-2.5 sm:grid-cols-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => ask(s)}
                  className="group rounded-2xl glass px-4 py-3 text-right text-[13px] leading-7 text-sand transition-all hover:border-gold/35 hover:text-ivory"
                >
                  <span className="ml-2 text-gold">✦</span>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <Bubble m={m} />
            </motion.div>
          ))}
        </AnimatePresence>

        {busy && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-end"
          >
            <div className="rounded-3xl rounded-tl-md glass-strong px-5 py-4">
              <div className="typing-dots flex items-center gap-1.5">
                <span /> <span /> <span />
                <span className="mr-2 bg-transparent text-xs text-ash">{TIPS[tip]}</span>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* مربع الإدخال */}
      <div className="py-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void ask(input);
          }}
          className="gold-ring flex items-end gap-2 rounded-3xl p-2.5"
        >
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(e.target.scrollHeight, 144)}px`;
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void ask(input);
              }
            }}
            rows={1}
            placeholder="اكتب سؤالك الديني هنا… مثال: ما حكم التعامل بالربا؟"
            className="max-h-36 flex-1 resize-none bg-transparent px-3 py-2.5 text-[15px] leading-7 text-ivory outline-none placeholder:text-ash/60"
          />
          <button
            type="submit"
            disabled={busy || input.trim().length < 2}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-l from-golddeep via-gold to-goldbright text-night shadow-[0_6px_20px_rgba(200,162,78,0.4)] transition-all hover:scale-105 disabled:opacity-40 disabled:hover:scale-100"
          >
            <SendHorizonal size={18} className="-scale-x-100" />
          </button>
        </form>
        <p className="mt-2.5 flex items-center justify-center gap-1.5 text-center text-[11px] text-ash/70">
          <CircleAlert size={12} />
          الإجابات مستخرجة نصًا من تفريغات القناة — وقد لا تغطي القناة كل الموضوعات.
        </p>
      </div>
    </div>
  );
}
