export default function GeoOrnament({
  size = 560,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 560 560"
      fill="none"
      aria-hidden
      className={`pointer-events-none select-none ${className}`}
    >
      <defs>
        <linearGradient id="go-a" x1="0" y1="0" x2="560" y2="560">
          <stop offset="0%" stopColor="#e9cd85" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#17b576" stopOpacity="0.28" />
        </linearGradient>
      </defs>
      <g className="animate-spin-slow" style={{ transformOrigin: "280px 280px" }}>
        <circle cx="280" cy="280" r="200" stroke="url(#go-a)" strokeWidth="1" />
        <circle cx="280" cy="280" r="262" stroke="url(#go-a)" strokeWidth="0.6" strokeDasharray="3 8" />
        <rect x="138" y="138" width="284" height="284" stroke="url(#go-a)" strokeWidth="1.1" rx="4" />
        <rect x="138" y="138" width="284" height="284" stroke="url(#go-a)" strokeWidth="1.1" rx="4" transform="rotate(45 280 280)" />
        <rect x="188" y="188" width="184" height="184" stroke="url(#go-a)" strokeWidth="0.8" rx="2" />
        <rect x="188" y="188" width="184" height="184" stroke="url(#go-a)" strokeWidth="0.8" rx="2" transform="rotate(45 280 280)" />
        {Array.from({ length: 16 }).map((_, i) => {
          const a = (i * Math.PI) / 8;
          const x1 = 280 + 200 * Math.cos(a);
          const y1 = 280 + 200 * Math.sin(a);
          const x2 = 280 + 262 * Math.cos(a);
          const y2 = 280 + 262 * Math.sin(a);
          return (
            <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="url(#go-a)" strokeWidth="0.7" />
          );
        })}
        <circle cx="280" cy="280" r="86" stroke="url(#go-a)" strokeWidth="1.2" />
        <rect x="236" y="236" width="88" height="88" stroke="url(#go-a)" strokeWidth="1" rx="2" />
        <rect x="236" y="236" width="88" height="88" stroke="url(#go-a)" strokeWidth="1" rx="2" transform="rotate(45 280 280)" />
      </g>
      <circle cx="280" cy="280" r="7" fill="#e9cd85" opacity="0.8" />
    </svg>
  );
}
