import Link from "next/link";
import { Database, ShieldCheck } from "lucide-react";
import BrandMark from "@/components/BrandMark";
import YoutubeIcon from "@/components/YoutubeIcon";
import { CHANNEL } from "@/db/schema";

export default function SiteFooter() {
  return (
    <footer className="relative mt-24 border-t border-white/5">
      <div className="divider-orn mx-auto max-w-3xl" />
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-4 py-10 sm:px-6">
        <div className="flex items-center gap-3">
          <BrandMark size={30} />
          <span className="font-display text-lg font-bold gold-text">مسلم وبس</span>
        </div>

        <p className="max-w-xl text-center text-sm leading-7 text-ash">
          كل الإجابات مستخرجة حرفيًا من النصوص المفرَّغة من فيديوهات قناة
          <a
            href={CHANNEL.url}
            target="_blank"
            rel="noreferrer"
            className="mx-1 font-semibold text-goldbright hover:underline"
          >
            «{CHANNEL.name}»
          </a>
          على يوتيوب، مع إرفاق رابط الفيديو المصدر لكل جواب.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-5 text-xs text-ash">
          <span className="flex items-center gap-1.5">
            <Database size={13} className="text-jade" />
            متصل بقاعدة بيانات حية
          </span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck size={13} className="text-jade" />
            محرك إجابة مستقل بلا خدمات خارجية
          </span>
          <a
            href={CHANNEL.url}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 hover:text-goldbright"
          >
            <YoutubeIcon size={13} className="text-jade" />
            قناة المصدر
          </a>
          <Link href="/ask" className="hover:text-goldbright">
            اطرح سؤالك
          </Link>
        </div>

        <p className="text-[11px] text-ash/60">
          أداة تعليمية للاسترشاد — عند الفتاوى المفصّلة راجع أهل العلم.
        </p>
      </div>
    </footer>
  );
}
