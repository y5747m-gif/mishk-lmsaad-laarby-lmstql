export default function BrandMark({ size = 40 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden
      className="shrink-0"
    >
      <defs>
        <linearGradient id="bm-gold" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="#e9cd85" />
          <stop offset="55%" stopColor="#c8a24e" />
          <stop offset="100%" stopColor="#8a6b2a" />
        </linearGradient>
        <linearGradient id="bm-jade" x1="64" y1="0" x2="0" y2="64">
          <stop offset="0%" stopColor="#17b576" />
          <stop offset="100%" stopColor="#0e5e42" />
        </linearGradient>
      </defs>
      {/* نجمة ثمانية من مربعين */}
      <rect
        x="18" y="18" width="28" height="28"
        stroke="url(#bm-gold)" strokeWidth="2.4" rx="2"
      />
      <rect
        x="18" y="18" width="28" height="28" rx="2"
        stroke="url(#bm-jade)" strokeWidth="2.4"
        transform="rotate(45 32 32)"
      />
      {/* هلال */}
      <path
        d="M38.5 32a8.2 8.2 0 1 1-7.9-10.4A6.6 6.6 0 1 0 38.5 32Z"
        fill="url(#bm-gold)"
      />
      {/* مئذنة متوهجة */}
      <rect x="40.5" y="24.5" width="2.6" height="15" rx="1.3" fill="url(#bm-jade)" />
      <circle cx="41.8" cy="22.4" r="2.1" fill="#e9cd85" />
    </svg>
  );
}
