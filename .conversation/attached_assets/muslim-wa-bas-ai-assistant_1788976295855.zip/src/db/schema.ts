import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

/* ─────────────────────────  قاعدة بيانات «مسلم وبس»  ───────────────────────── */

/** فيديوهات القناة المستخرجة من يوتيوب مع نصوصها الكاملة */
export const videos = pgTable(
  "videos",
  {
    id: serial("id").primaryKey(),
    videoId: text("video_id").notNull().unique(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    url: text("url").notNull(),
    thumbnail: text("thumbnail").notNull().default(""),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    views: integer("views").notNull().default(0),
    hasTranscript: boolean("has_transcript").notNull().default(false),
    transcript: text("transcript").notNull().default(""),
    wordCount: integer("word_count").notNull().default(0),
    syncedAt: timestamp("synced_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("videos_video_id_idx").on(t.videoId)],
);

/** مقاطع نصية مُجزّأة من النصوص لأغراض الاسترجاع الذكي (RAG) */
export const chunks = pgTable(
  "chunks",
  {
    id: serial("id").primaryKey(),
    videoId: text("video_id").notNull(),
    idx: integer("idx").notNull(),
    content: text("content").notNull(),
    tokenCount: integer("token_count").notNull().default(0),
  },
  (t) => [index("chunks_video_id_idx").on(t.videoId)],
);

/** محادثات المستخدمين مع الذكاء الاصطناعي */
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("محادثة جديدة"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/** رسائل المحادثة (سؤال / جواب) مع المصادر */
export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id").notNull(),
    role: text("role").notNull(), // "user" | "assistant"
    content: text("content").notNull(),
    sources: jsonb("sources").$type<
      {
        videoId: string;
        title: string;
        url: string;
        thumbnail: string;
        snippet: string;
        relevance: number;
      }[]
    >(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("messages_conversation_idx").on(t.conversationId)],
);

/** حالة المزامنة مع قناة يوتيوب (مفتاح/قيمة) */
export const syncState = pgTable("sync_state", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const CHANNEL = {
  id: "UCv0g_v1C6JcZALvrkDu98AQ",
  name: "تعلم دينك لتنجو وتسعد",
  url: "https://youtube.com/channel/UCv0g_v1C6JcZALvrkDu98AQ",
} as const;
