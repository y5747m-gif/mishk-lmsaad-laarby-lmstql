import { eq as eq2 } from "drizzle-orm";
import { db } from "@/db";
import { chunks, videos, syncState, CHANNEL } from "@/db/schema";
import {
  tokenize,
  stemTokens,
  expandQuery,
  normalizeArabic,
} from "@/lib/ai/arabic";
import { ensureSynced, syncChannel } from "@/lib/youtube";

/* ═══════════════  «مسلم وبس» — مُحرّك الإجابة المستقِل (Retrieval AI)  ═══════════════
   محرك عربي خالص بلا اعتماد على خدمات خارجية: فهرس BM25 داخل الذاكرة فوق
   المقاطع المستخرجة من نصوص فيديوهات القناة، مع توسيع مرادفات وتعزيز العناوين. */

export type Source = {
  videoId: string;
  title: string;
  url: string;
  thumbnail: string;
  snippet: string;
  relevance: number; // 0..1
};

export type EngineAnswer = {
  kind: "answer" | "greeting" | "fallback" | "empty-kb";
  answer: string;
  sources: Source[];
  confidence: number; // 0..1
  matchedVideos: number;
  debug?: Record<string, unknown>;
};

type IndexChunk = {
  videoId: string;
  content: string;
  stems: string[];
  title: string;
  url: string;
  thumbnail: string;
  titleStems: Set<string>;
  descStems: Set<string>;
};

type Index = {
  chunks: IndexChunk[];
  df: Map<string, number>;
  avgLen: number;
  syncStamp: string;
};

/* ── بناء الفهرس وتخزينه مؤقتًا في الذاكرة مع إبطاله بعد كل مزامنة ── */
let cachedIndex: Index | null = null;

async function currentSyncStamp(): Promise<string> {
  const rows = await db.select().from(syncState);
  const s = rows.find((r: { key: string }) => r.key === "last_sync");
  return s ? `${s.value}#${s.updatedAt.getTime()}` : "never";
}

async function buildIndex(stamp: string): Promise<Index> {
  const allChunks = await db
    .select({
      videoId: chunks.videoId,
      content: chunks.content,
      title: videos.title,
      url: videos.url,
      thumbnail: videos.thumbnail,
      description: videos.description,
    })
    .from(chunks)
    .innerJoin(videos, eq2(chunks.videoId, videos.videoId));

  const videoRows = await db
    .select({
      videoId: videos.videoId,
      title: videos.title,
      description: videos.description,
    })
    .from(videos);
  const videoMeta = new Map(videoRows.map((v) => [v.videoId, v]));

  const indexChunks: IndexChunk[] = allChunks.map((c) => ({
    videoId: c.videoId,
    content: c.content,
    stems: stemTokens(tokenize(c.content)),
    title: c.title,
    url: c.url,
    thumbnail: c.thumbnail,
    titleStems: new Set(stemTokens(tokenize(c.title))),
    descStems: new Set(stemTokens(tokenize(c.description ?? ""))),
  }));

  // أضف "مقاطع وصفية" للفيديوهات بلا نص مستخرج حتى تظهر في النتائج
  const withTranscript = new Set(allChunks.map((c) => c.videoId));
  for (const v of videoRows) {
    if (withTranscript.has(v.videoId)) continue;
    const text = `${v.title}. ${v.description ?? ""}`.trim();
    if (text.length < 8) continue;
    const meta = videoMeta.get(v.videoId);
    indexChunks.push({
      videoId: v.videoId,
      content: text,
      stems: stemTokens(tokenize(text)),
      title: v.title,
      url: `https://www.youtube.com/watch?v=${v.videoId}`,
      thumbnail: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
      titleStems: new Set(stemTokens(tokenize(v.title))),
      descStems: new Set(stemTokens(tokenize(meta?.description ?? ""))),
    });
  }

  const df = new Map<string, number>();
  let totalLen = 0;
  for (const c of indexChunks) {
    totalLen += c.stems.length;
    const seen = new Set(c.stems);
    for (const t of seen) df.set(t, (df.get(t) ?? 0) + 1);
  }

  return {
    chunks: indexChunks,
    df,
    avgLen: totalLen / Math.max(indexChunks.length, 1),
    syncStamp: stamp,
  };
}

export async function getIndex(): Promise<Index> {
  const stamp = await currentSyncStamp();
  if (cachedIndex && cachedIndex.syncStamp === stamp) return cachedIndex;
  cachedIndex = await buildIndex(stamp);
  return cachedIndex;
}

export function bustIndex() {
  cachedIndex = null;
}

/* ── الترحيب والتحيات ── */
const GREETING_RE =
  /(السلام عليكم|سلام عليكم|صباح الخير|مساء الخير|اهلا|مرحبا|هلا|اهلين|هاي)/;

/** التحية تُعامل كتحية فقط إذا كانت الرسالة قصيرة — حتى لا تُبتلع كلمة «الإسلام» داخل الأسئلة */
function isGreeting(q: string): boolean {
  const n = normalizeArabic(q);
  return n.length <= 30 && GREETING_RE.test(n);
}

function greetingAnswer(): EngineAnswer {
  return {
    kind: "greeting",
    confidence: 1,
    matchedVideos: 0,
    sources: [],
    answer: [
      "**وعليكم السلام ورحمة الله وبركاته 🌙**".replace(" 🌙", ""),
      "",
      `أهلًا بك في «مسلم وبس» — ذكاءٌ اصطناعي يستخرج إجابات أسئلتك الدينية من نصوص فيديوهات قناة **«${CHANNEL.name}»** حرفيًا، ويرفقها بروابط الفيديوهات الموثقة.`,
      "",
      "اسألني مثلًا: **ما عقوبة الربا؟** أو **أهمية الدعوة إلى الله؟** أو **ما حكم شتم الأب والأم؟**",
    ].join("\n"),
  };
}

/* ── اختيار نافذة نصية حول كثافة كلمات السؤال داخل المقطع ── */
function bestWindow(
  content: string,
  queryStems: Set<string>,
  width = 58,
): string {
  const words = content.split(/\s+/);
  if (words.length <= width) return content;
  const hits: number[] = [];
  words.forEach((w, i) => {
    const stems = stemTokens(tokenize(w));
    if (stems.some((s) => queryStems.has(s)) || queryStems.has(normalizeArabic(w)))
      hits.push(i);
  });
  if (hits.length === 0) return words.slice(0, width).join(" ") + "…";
  const median = hits[Math.floor(hits.length / 2)];
  let start = Math.max(0, median - Math.floor(width / 2));
  if (start + width > words.length) start = words.length - width;
  const prefix = start > 0 ? "…" : "";
  const suffix = start + width < words.length ? "…" : "";
  return prefix + words.slice(start, start + width).join(" ") + suffix;
}

/* ── توليد الإجابة ── */
const K1 = 1.5;
const B = 0.75;

export async function answerQuestion(question: string): Promise<EngineAnswer> {
  const q = question.trim();
  if (q.length < 2 || isGreeting(q)) {
    return greetingAnswer();
  }

  await ensureSynced();
  let index = await getIndex();

  // أول تشغيل: القاعدة فارغة — نزامن فورًا (حظر مؤقت) ثم نعيد البناء
  if (index.chunks.length === 0) {
    await syncChannel(false);
    bustIndex();
    index = await getIndex();
    if (index.chunks.length === 0) {
      return {
        kind: "empty-kb",
        confidence: 0,
        matchedVideos: 0,
        sources: [],
        answer: [
          "**قاعدة المعرفة قيد البناء الآن**",
          "",
          `نستخرج حاليًا نصوص فيديوهات قناة «${CHANNEL.name}» من يوتيوب. أعد طرح سؤالك بعد لحظات.`,
        ].join("\n"),
      };
    }
  }

  // ترميز السؤال وتوسيعه
  const qTokens = expandQuery(tokenize(q));
  const qStems = new Set(stemTokens(qTokens));
  const strictStems = new Set(stemTokens(tokenize(q))); // بدون توسيع — للثقة

  if (qStems.size === 0) return greetingAnswer();

  // نقاط BM25 مع تعزيز عنوان الفيديو ووصفه — التعزيز مرجّح بندرة الكلمة (idf)
  const N = index.chunks.length;
  const idfOf = (term: string) => {
    const df = index.df.get(term) ?? 0;
    return Math.log(1 + (N - df + 0.5) / (df + 0.5));
  };
  const scored = index.chunks.map((c) => {
    const tf = new Map<string, number>();
    for (const s of c.stems) tf.set(s, (tf.get(s) ?? 0) + 1);
    let score = 0;
    for (const term of qStems) {
      const fq = tf.get(term) ?? 0;
      if (fq === 0) continue;
      const idf = idfOf(term);
      score +=
        idf * ((fq * (K1 + 1)) / (fq + K1 * (1 - B + (B * c.stems.length) / index.avgLen)));
    }
    // الكلمات النادرة في العنوان (مثل اسم سورة) أبلغ دلالة من الشائعة
    let titleBoost = 0;
    for (const s of strictStems) {
      if (c.titleStems.has(s)) titleBoost += idfOf(s) * 1.1;
    }
    titleBoost = Math.min(titleBoost, 7);
    let descBoost = 0;
    for (const s of strictStems) {
      if (c.descStems.has(s)) descBoost += idfOf(s) * 0.25;
    }
    descBoost = Math.min(descBoost, 1.5);
    return { chunk: c, score: score + titleBoost + descBoost, pure: score };
  });

  scored.sort((a, b) => b.score - a.score);
  const best = scored[0];
  const bestSetDbg = best ? new Set(best.chunk.stems) : new Set<string>();
  const distinctHitsDbg = best
    ? [...strictStems].filter((s) => bestSetDbg.has(s)).length
    : 0;
  const titleHitsDbg = best
    ? [...strictStems].filter((s) => best.chunk.titleStems.has(s)).length
    : 0;
  const dbg = {
    qTokens,
    qStems: [...qStems],
    strictStems: [...strictStems],
    indexChunks: index.chunks.length,
    bestScore: best?.score ?? null,
    bestTitle: best?.chunk.title ?? null,
    bestScoreSecond: scored[1]?.score ?? null,
    distinctHits: distinctHitsDbg,
    titleHits: titleHitsDbg,
  };
  if (!best || best.score <= 0.35) {
    return { ...fallbackAnswer(q), debug: { ...dbg, reason: "low-score" } };
  }

  // حارس الصلة: الأسئلة متعددة الكلمات يجب أن تطابق كلمتين مختلفتين على الأقل
  // داخل أفضل مقطع (وليس مجرد مصادفة لفظية واحدة) وإلا يُعتبر خارج نطاق القناة
  if (strictStems.size >= 2 && distinctHitsDbg + titleHitsDbg < 2) {
    return { ...fallbackAnswer(q), debug: { ...dbg, reason: "distinct-guard" } };
  }

  // تنويع: مقطع واحد لكل فيديو بحد أقصى ٢ لنفس الفيديو
  const picked: typeof scored = [];
  const perVideo = new Map<string, number>();
  for (const s of scored) {
    if (picked.length >= 4) break;
    const count = perVideo.get(s.chunk.videoId) ?? 0;
    if (count >= 2) continue;
    if (s.score < best.score * 0.22) continue;
    perVideo.set(s.chunk.videoId, count + 1);
    picked.push(s);
  }

  const bestScore = Math.max(best.score, 1);
  const seenVideos = new Set<string>();
  const sources: Source[] = [];
  for (const s of picked) {
    if (seenVideos.has(s.chunk.videoId)) continue; // بطاقة واحدة لكل فيديو
    seenVideos.add(s.chunk.videoId);
    sources.push({
      videoId: s.chunk.videoId,
      title: s.chunk.title,
      url: s.chunk.url,
      thumbnail: s.chunk.thumbnail,
      snippet: bestWindow(s.chunk.content, qStems),
      relevance: Math.min(0.99, Math.max(0.12, s.score / bestScore)),
    });
  }

  const matchedVideos = new Set(picked.map((p) => p.chunk.videoId)).size;
  const confidence = Math.min(
    0.97,
    Math.max(0.2, best.score / 16 + (matchedVideos - 1) * 0.07),
  );

  // توليد نص الإجابة من المقاطع المستخرجة حرفيًا
  const lines: string[] = [];
  lines.push(`**الجواب من نصوص قناة «${CHANNEL.name}»:**`);
  lines.push("");
  picked.slice(0, 3).forEach((s, i) => {
    const excerpt = bestWindow(s.chunk.content, qStems, i === 0 ? 74 : 52);
    lines.push(`«${excerpt}»`);
    lines.push(`**— من فيديو:** ${s.chunk.title}`);
    if (i < Math.min(picked.length, 3) - 1) lines.push("");
  });
  lines.push("");
  lines.push(
    picked.length > 0
      ? "روابط الفيديوهات الموثقة المتعلقة بسؤالك مرفقة أدناه — اضغط على أي بطاقة للمشاهدة الكاملة على يوتيوب."
      : "",
  );

  return {
    kind: "answer",
    answer: lines.filter((l) => l !== "").join("\n"),
    sources,
    confidence,
    matchedVideos,
  };
}

function fallbackAnswer(question: string): EngineAnswer {
  void question;
  return {
    kind: "fallback",
    confidence: 0,
    matchedVideos: 0,
    sources: [],
    answer: [
      "**لم أجد في نصوص القناة ما يطابق سؤالك بدقة.**",
      "",
      "جرّب إحدى هذه الطرق:",
      "• أعد صياغة السؤال بكلمات أبسط (مثال: «الربا»، «الدعوة إلى الله»، «شتم الوالدين»)",
      "• اسأل عن موضوع من موضوعات خطب القناة مثل: تفسير السور، الدعوة، الربا، بر الوالدين",
      "• تصفّح مكتبة الفيديوهات المفهرسة من صفحة «المكتبة»",
      "",
      `ملاحظة: إجاباتي مستخرجة **حصريًا** من نصوص قناة «${CHANNEL.name}» على يوتيوب، لذا قد لا تجيب القناة عن كل سؤال.`,
    ].join("\n"),
  };
}
