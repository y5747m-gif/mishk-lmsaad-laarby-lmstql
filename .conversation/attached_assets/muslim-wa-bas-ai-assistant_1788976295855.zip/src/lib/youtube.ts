import { YoutubeTranscript } from "youtube-transcript";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { videos, chunks, syncState, CHANNEL } from "@/db/schema";

/* ═══════════════════════  مُزامنة قناة يوتيوب  ═══════════════════════ */

export type ChannelVideoMeta = {
  videoId: string;
  title: string;
  description: string;
  url: string;
  thumbnail: string;
  publishedAt: Date | null;
  views: number;
};

const RSS_URL = `https://www.youtube.com/feeds/videos.xml?channel_id=${CHANNEL.id}`;
const VIDEOS_PAGE = `https://www.youtube.com/channel/${CHANNEL.id}/videos`;
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36";

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .trim();
}

/** استخراج أحدث الفيديوهات من RSS مع بياناتها الكاملة */
export async function fetchRssVideos(): Promise<ChannelVideoMeta[]> {
  const res = await fetch(RSS_URL, {
    headers: { "User-Agent": UA },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`RSS fetch failed: ${res.status}`);
  const xml = await res.text();

  const out: ChannelVideoMeta[] = [];
  const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) ?? [];
  for (const entry of entries) {
    const pick = (re: RegExp) => {
      const m = entry.match(re);
      return m ? decodeEntities(m[1]) : "";
    };
    const videoId = pick(/<yt:videoId>([^<]+)<\/yt:videoId>/);
    if (!videoId) continue;
    const title = pick(/<media:title>([^<]*)<\/media:title>/) || pick(/<title>([^<]*)<\/title>/);
    const published = pick(/<published>([^<]+)<\/published>/);
    const views = pick(/<media:statistics views="(\d+)"/);
    out.push({
      videoId,
      title: title || "بدون عنوان",
      description: pick(/<media:description>([\s\S]*?)<\/media:description>/),
      url: `https://www.youtube.com/watch?v=${videoId}`,
      thumbnail:
        pick(/<media:thumbnail url="([^"]+)"/) ||
        `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
      publishedAt: published ? new Date(published) : null,
      views: views ? Number(views) : 0,
    });
  }
  return out;
}

/** كشط صفحة القناة لجمع معرّفات فيديوهات أقدم لا يوفرها RSS */
export async function fetchAllVideoIds(): Promise<string[]> {
  try {
    const res = await fetch(VIDEOS_PAGE, {
      headers: { "User-Agent": UA, "Accept-Language": "ar,en" },
      cache: "no-store",
    });
    if (!res.ok) return [];
    const html = await res.text();
    const ids = new Set<string>();
    for (const m of html.matchAll(/"videoId":"([\w-]{11})"/g)) ids.add(m[1]);
    return [...ids];
  } catch {
    return [];
  }
}

/** عنوان الفيديو عبر oEmbed للفيديوهات خارج RSS */
async function fetchOEmbedTitle(videoId: string): Promise<string> {
  try {
    const res = await fetch(
      `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`,
      { headers: { "User-Agent": UA }, cache: "no-store" },
    );
    if (!res.ok) return "";
    const data = (await res.json()) as { title?: string };
    return data.title ?? "";
  } catch {
    return "";
  }
}

/** تنظيف النص المستخرج من علامات الترجمة الآلية */
export function cleanTranscript(text: string): string {
  return text
    .replace(/\[(موسيقى|تصفيق|ضحك|تنحنُح|موسيقى مبهجة)\]/g, " ")
    .replace(/\[(music|applause|laughter)\]/gi, " ")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/[^\S\n]+/g, " ")
    .replace(/\s+([،.؟!:؛])/g, "$1")
    .trim();
}

/** جلب النص الكامل للفيديو من ترجمة يوتيوب */
export async function fetchTranscriptText(videoId: string): Promise<string> {
  try {
    let segments;
    try {
      segments = await YoutubeTranscript.fetchTranscript(videoId, { lang: "ar" });
    } catch {
      segments = await YoutubeTranscript.fetchTranscript(videoId);
    }
    const raw = segments.map((s) => s.text).join(" ");
    return cleanTranscript(raw);
  } catch {
    return "";
  }
}

/** تقسيم النص إلى مقاطع متداخلة (~130 كلمة مع تداخل 30) لتحسين دقة الاسترجاع */
export function chunkText(text: string, size = 130, overlap = 30): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  if (words.length <= size + overlap) return [words.join(" ")];
  const out: string[] = [];
  const step = size - overlap;
  for (let start = 0; start < words.length; start += step) {
    const slice = words.slice(start, start + size);
    if (slice.length < size / 3 && out.length > 0) break;
    out.push(slice.join(" "));
    if (start + size >= words.length) break;
  }
  return out;
}

/* ───────────────────────────  التزامن الرئيسي  ─────────────────────────── */

let syncInFlight: Promise<SyncReport> | null = null;
const SYNC_FRESH_MS = 1000 * 60 * 60 * 6; // ٦ ساعات

export type SyncReport = {
  ok: boolean;
  channelName: string;
  videosFound: number;
  videosUpserted: number;
  transcriptsFetched: number;
  chunksCreated: number;
  durationMs: number;
  error?: string;
};

export async function getLastSync(): Promise<Date | null> {
  const rows = await db.select().from(syncState);
  const row = rows.find((r: { key: string }) => r.key === "last_sync");
  return row ? new Date(row.value) : null;
}

export async function isSyncFresh(): Promise<boolean> {
  const last = await getLastSync().catch(() => null);
  return !!last && Date.now() - last.getTime() < SYNC_FRESH_MS;
}

/** مزامنة القناة: بيانات الفيديوهات + النصوص المستخرجة + التجزئة — مع قفل يمنع التكرار */
export function syncChannel(force = false): Promise<SyncReport> {
  if (syncInFlight) return syncInFlight;
  syncInFlight = doSync(force).finally(() => {
    syncInFlight = null;
  });
  return syncInFlight;
}

async function setSyncValue(key: string, value: string) {
  await db
    .insert(syncState)
    .values({ key, value, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: syncState.key,
      set: { value, updatedAt: new Date() },
    });
}

async function doSync(force: boolean): Promise<SyncReport> {
  const started = Date.now();
  const report: SyncReport = {
    ok: false,
    channelName: CHANNEL.name,
    videosFound: 0,
    videosUpserted: 0,
    transcriptsFetched: 0,
    chunksCreated: 0,
    durationMs: 0,
  };

  try {
    if (!force && (await isSyncFresh())) {
      report.ok = true;
      report.error = "synced-recently";
      return report;
    }

    // ١) جمع الفيديوهات من RSS + صفحة القناة
    const rssVideos = await fetchRssVideos();
    const allIds = await fetchAllVideoIds();
    const metaMap = new Map<string, ChannelVideoMeta>();
    for (const v of rssVideos) metaMap.set(v.videoId, v);
    report.videosFound = new Set([...metaMap.keys(), ...allIds]).size;

    // أكمل المعرّفات الناقصة ببيانات oEmbed (بحد أقصى ٢٥ فيديو إضافي)
    const missingIds = allIds.filter((id) => !metaMap.has(id)).slice(0, 25);
    for (const id of missingIds) {
      const title = await fetchOEmbedTitle(id);
      if (!title) continue;
      metaMap.set(id, {
        videoId: id,
        title,
        description: "",
        url: `https://www.youtube.com/watch?v=${id}`,
        thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        publishedAt: null,
        views: 0,
      });
    }

    // ٢) حدد الفيديوهات الموجودة بالفعل مع نصوصها
    const existing = await db
      .select({
        videoId: videos.videoId,
        hasTranscript: videos.hasTranscript,
        title: videos.title,
      })
      .from(videos);
    const existingMap = new Map(existing.map((e) => [e.videoId, e]));

    // ٣) أدخل/حدّث واجلب النصوص
    const metas = [...metaMap.values()];
    const CONCURRENCY = 3;
    for (let i = 0; i < metas.length; i += CONCURRENCY) {
      await Promise.all(
        metas.slice(i, i + CONCURRENCY).map(async (meta) => {
          try {
            const prev = existingMap.get(meta.videoId);
            const titleChanged = prev && prev.title !== meta.title;
            const transcript =
              force || !prev || !prev.hasTranscript || titleChanged
                ? await fetchTranscriptText(meta.videoId)
                : "";
            const fetched = transcript.length > 0;
            if (fetched) report.transcriptsFetched++;

            const hasTranscript = fetched || (prev?.hasTranscript ?? false);
            await db
              .insert(videos)
              .values({
                videoId: meta.videoId,
                title: meta.title,
                description: meta.description,
                url: meta.url,
                thumbnail: meta.thumbnail,
                publishedAt: meta.publishedAt,
                views: meta.views,
                hasTranscript,
                transcript: fetched ? transcript : "",
                wordCount: fetched ? transcript.split(/\s+/).length : 0,
                syncedAt: new Date(),
              })
              .onConflictDoUpdate({
                target: videos.videoId,
                set: {
                  title: meta.title,
                  description: meta.description,
                  url: meta.url,
                  thumbnail: meta.thumbnail,
                  publishedAt: meta.publishedAt ?? undefined,
                  views: meta.views,
                  ...(fetched
                    ? {
                        hasTranscript: true,
                        transcript,
                        wordCount: transcript.split(/\s+/).length,
                      }
                    : {}),
                  syncedAt: new Date(),
                },
              });
            report.videosUpserted++;

            // أعد بناء المقاطع إذا جلبنا نصًا جديدًا
            if (fetched) {
              await db.delete(chunks).where(eq(chunks.videoId, meta.videoId));
              const pieces = chunkText(transcript);
              if (pieces.length > 0) {
                await db.insert(chunks).values(
                  pieces.map((content, idx) => ({
                    videoId: meta.videoId,
                    idx,
                    content,
                    tokenCount: content.split(/\s+/).length,
                  })),
                );
                report.chunksCreated += pieces.length;
              }
            }
          } catch {
            /* فيديو فاشل لا يُسقط المزامنة */
          }
        }),
      );
    }

    await setSyncValue("last_sync", new Date().toISOString());
    report.ok = true;
  } catch (e) {
    report.error = e instanceof Error ? e.message : String(e);
  } finally {
    report.durationMs = Date.now() - started;
  }
  return report;
}

/** مزامنة كسولة: تُشغَّل تلقائيًا عند أول استخدام إذا كانت القاعدة فارغة أو قديمة */
export async function ensureSynced(): Promise<void> {
  try {
    const fresh = await isSyncFresh();
    if (!fresh) void syncChannel(false);
  } catch {
    /* لا شيء — سيتحقق لاحقًا */
  }
}
