export async function register() {
  // عند إقلاع الخادم: شغّل مزامنة القناة في الخلفية إذا كانت القاعدة فارغة أو قديمة
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { ensureSynced } = await import("@/lib/youtube");
    void ensureSynced();
  }
}
