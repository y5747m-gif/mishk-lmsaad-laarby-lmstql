import { Suspense } from "react";
import type { Metadata } from "next";
import LibraryBrowser from "@/components/LibraryBrowser";

export const metadata: Metadata = {
  title: "مكتبة النصوص — مسلم وبس",
  description:
    "تصفح الفيديوهات المفهرسة من قناة «تعلم دينك لتنجو وتسعد» مع نصوصها المستخرجة وروابطها على يوتيوب.",
};

export default function LibraryPage() {
  return (
    <main className="relative mx-auto min-h-screen max-w-6xl px-4 py-12 sm:px-6">
      <div className="pattern-geo pointer-events-none absolute inset-0 opacity-20" />
      <div className="relative">
        <header className="text-center">
          <p className="text-xs font-bold tracking-widest text-jade">قاعدة المعرفة</p>
          <h1 className="font-display mt-3 text-4xl font-bold text-ivory sm:text-5xl">
            مكتبة النصوص المستخرجة
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-ash">
            كل فيديوهات القناة المزامَنة مع تفريغاتها العربية — ابحث فيها، أو اسأل
            الذكاء الاصطناعي ليستخرج لك الجواب منها مباشرة.
          </p>
          <div className="divider-orn mx-auto mt-6 w-56" />
        </header>

        <Suspense
          fallback={
            <div className="mt-16 grid place-items-center">
              <div className="typing-dots flex items-center gap-1.5">
                <span /> <span /> <span />
              </div>
            </div>
          }
        >
          <LibraryBrowser />
        </Suspense>
      </div>
    </main>
  );
}
