import type { Metadata } from "next";
import { Amiri, Cairo } from "next/font/google";
import "./globals.css";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";

const amiri = Amiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  variable: "--font-amiri",
});

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
});

export const metadata: Metadata = {
  title: "مسلم وبس — ذكاء اصطناعي يجيب من قناة «تعلم دينك لتنجو وتسعد»",
  description:
    "أداة ذكاء اصطناعي عربية تستخرج نصوص فيديوهات قناة «تعلم دينك لتنجو وتسعد» من يوتيوب وتجيب على أسئلتك الدينية نصًا مع روابط الفيديوهات الموثقة.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl" className={`${amiri.variable} ${cairo.variable}`}>
      <body className="bg-night text-ivory antialiased">
        <SiteHeader />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
