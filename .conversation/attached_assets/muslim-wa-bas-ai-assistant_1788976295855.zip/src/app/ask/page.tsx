import { Suspense } from "react";
import type { Metadata } from "next";
import Chat from "@/components/Chat";

export const metadata: Metadata = {
  title: "اسأل — مسلم وبس",
  description:
    "اطرح سؤالك الديني ويستخرج لك «مسلم وبس» الجواب من نصوص فيديوهات قناة «تعلم دينك لتنجو وتسعد» مع روابط الفيديوهات.",
};

export default function AskPage() {
  return (
    <main className="relative">
      <div className="pattern-geo pointer-events-none absolute inset-0 opacity-30" />
      <Suspense
        fallback={
          <div className="mx-auto grid h-[calc(100vh-4rem)] max-w-5xl place-items-center px-4">
            <div className="typing-dots flex items-center gap-1.5">
              <span /> <span /> <span />
            </div>
          </div>
        }
      >
        <Chat />
      </Suspense>
    </main>
  );
}
