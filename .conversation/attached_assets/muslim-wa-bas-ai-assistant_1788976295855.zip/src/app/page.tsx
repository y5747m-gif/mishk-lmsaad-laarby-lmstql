import Link from "next/link";
import { sql } from "drizzle-orm";
import {
  Sparkles,
  LibraryBig,
  MessageCircleQuestion,
  DownloadCloud,
  ScanText,
  BrainCircuit,
  Gauge,
  ArrowLeft,
  FileText,
  Clapperboard,
  Database,
  MessagesSquare,
} from "lucide-react";
import { db } from "@/db";
import { videos, chunks, CHANNEL } from "@/db/schema";
import { ensureSynced, getLastSync } from "@/lib/youtube";
import YoutubeIcon from "@/components/YoutubeIcon";
import GeoOrnament from "@/components/GeoOrnament";
import Reveal from "@/components/Reveal";

export const dynamic = "force-dynamic";

const SUGGESTED = [
  "ما عقوبة الربا في الإسلام؟",
  "ما أهمية الدعوة إلى الله؟",
  "ما حكم شتم الأب والأم؟",
  "ما مختصر رحلة الإنسان من البداية إلى النهاية؟",
  "تفسير سورة المدثر",
  "ما آداب الداعي والمدعوين؟",
];

const TOPICS = [
  "تفسير القرآن", "الربا وعقوبته", "الدعوة إلى الله", "بر الوالدين", "خطب الجمعة",
  "التزكية والقلوب", "آداب الداعية", "رحلة الإنسان", "سورة المدثر", "سورة القيامة",
];

async function getStats() {
  try {
    await ensureSynced();
    const [v] = await db
      .select({
        total: sql<number>`count(*)::int`,
        transcribed: sql<number>`count(*) filter (where ${videos.hasTranscript})::int`,
        words: sql<number>`coalesce(sum(${videos.wordCount}),0)::int`,
      })
      .from(videos);
    const [c] = await db.select({ total: sql<number>`count(*)::int` }).from(chunks);
    const lastSync = await getLastSync();
    return {
      videos: v?.total ?? 0,
      transcribed: v?.transcribed ?? 0,
      words: v?.words ?? 0,
      chunks: c?.total ?? 0,
      lastSync,
    };
  } catch {
    return { videos: 0, transcribed: 0, words: 0, chunks: 0, lastSync: null as Date | null };
  }
}

export default async function HomePage() {
  const stats = await getStats();
  const fmt = new Intl.NumberFormat("ar-EG");

  return (
    <main className="relative overflow-hidden">
      {/* ─────────────── البطل ─────────────── */}
      <section className="relative flex min-h-[92vh] items-center justify-center px-4 py-20 sm:px-6">
        <div className="pattern-geo absolute inset-0 opacity-60" />
        <GeoOrnament
          size={640}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-45"
        />
        <div className="absolute inset-x-0 -top-24 h-72 bg-[radial-gradient(600px_220px_at_50%_0%,rgba(233,205,133,0.16),transparent_70%)]" />

        <div className="relative z-10 mx-auto max-w-4xl text-center">
          <Reveal>
            <div className="mx-auto mb-8 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs text-sand animate-float">
              <span className="h-1.5 w-1.5 rounded-full bg-jade animate-pulse-soft" />
              متصل بقاعدة بيانات حية ومحرك إجابة مستقل
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            <h1 className="font-display text-[clamp(3.4rem,10vw,7rem)] font-bold leading-none gold-text">
              مسلم وبس
            </h1>
          </Reveal>

          <Reveal delay={0.16}>
            <p className="mx-auto mt-4 max-w-2xl text-balance text-lg leading-9 text-sand sm:text-xl sm:leading-10">
              ذكاءٌ اصطناعي يستمع إلى فيديوهات قناة
              <span className="mx-1 font-bold text-goldbright">«{CHANNEL.name}»</span>
              ، يستخرج نصوصها كاملة، ثم يجيب على أسئلتك الدينية
              <span className="mx-1 font-bold text-mint">نصًا وبالدليل</span>
              مع رابط الفيديو الموثّق لكل جواب.
            </p>
          </Reveal>

          <Reveal delay={0.24}>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/ask"
                className="group flex items-center gap-2 rounded-full bg-gradient-to-l from-golddeep via-gold to-goldbright px-8 py-3.5 text-base font-bold text-night shadow-[0_10px_40px_rgba(200,162,78,0.4)] transition-all hover:scale-[1.04] hover:shadow-[0_14px_52px_rgba(200,162,78,0.55)]"
              >
                <MessageCircleQuestion size={18} />
                اسأل الذكاء الآن
                <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" />
              </Link>
              <Link
                href="/library"
                className="flex items-center gap-2 rounded-full glass-strong px-7 py-3.5 text-base font-semibold text-ivory transition-all hover:scale-[1.03] hover:border-gold/40"
              >
                <LibraryBig size={18} className="text-gold" />
                مكتبة النصوص
              </Link>
            </div>
          </Reveal>

          <Reveal delay={0.32}>
            <div className="mx-auto mt-14 grid max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { icon: Clapperboard, n: stats.videos, label: "فيديو مفهرس" },
                { icon: ScanText, n: stats.transcribed, label: "نص مستخرج" },
                { icon: FileText, n: stats.words, label: "كلمة عربية" },
                { icon: Database, n: stats.chunks, label: "مقطع معرفي" },
              ].map((s) => (
                <div key={s.label} className="glass rounded-2xl px-3 py-4">
                  <s.icon size={17} className="mx-auto mb-2 text-jade" />
                  <div className="font-display text-2xl font-bold text-goldbright">
                    {fmt.format(s.n)}
                  </div>
                  <div className="mt-0.5 text-[11px] text-ash">{s.label}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ─────────────── شريط الموضوعات ─────────────── */}
      <div className="relative border-y border-white/5 bg-abyss/60 py-4">
        <div className="flex w-max animate-marquee gap-3 pr-3" dir="ltr">
          {[...TOPICS, ...TOPICS].map((t, i) => (
            <span
              key={i}
              dir="rtl"
              className="whitespace-nowrap rounded-full border border-white/8 px-4 py-1.5 text-xs text-sand"
            >
              ✦ {t}
            </span>
          ))}
        </div>
      </div>

      {/* ─────────────── كيف يعمل ─────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
        <Reveal className="text-center">
          <p className="text-sm font-semibold tracking-widest text-jade">آلية العمل</p>
          <h2 className="font-display mt-3 text-4xl font-bold text-ivory sm:text-5xl">
            من يوتيوب… إلى جوابٍ موثّق
          </h2>
          <div className="divider-orn mx-auto mt-6 w-56" />
        </Reveal>

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {[
            {
              icon: DownloadCloud,
              step: "الخطوة ١",
              title: "استخراج النصوص",
              body: "نزامن قاعدة البيانات مع القناة تلقائيًا ونستخرج التفريغ العربي الكامل لكل فيديو (خطب، تفسير، مواعظ) مع عنوانه ورابطه.",
            },
            {
              icon: BrainCircuit,
              step: "الخطوة ٢",
              title: "فهم السؤال",
              body: "محرك لغوي عربي مستقل يطبيع سؤالك (تشكيل، همزات، مرادفات شرعية) ويطابقه مع مئات المقاطع المعرفية المفهرسة بتقنية BM25.",
            },
            {
              icon: MessagesSquare,
              step: "الخطوة ٣",
              title: "جواب بالمصدر",
              body: "تصلك الإجابة نصًا من كلام أهل العلم في الفيديو نفسه، مع بطاقات روابط الفيديوهات المتعلقة بسؤالك للمشاهدة الكاملة.",
            },
          ].map((f, i) => (
            <Reveal key={f.title} delay={i * 0.12}>
              <div className="group relative h-full overflow-hidden rounded-3xl glass p-8 transition-all duration-500 hover:-translate-y-2 hover:border-gold/30">
                <div className="absolute -left-8 -top-8 h-32 w-32 rounded-full bg-[radial-gradient(circle,rgba(23,181,118,0.18),transparent_70%)] transition-opacity group-hover:opacity-100" />
                <div className="mb-5 inline-flex rounded-2xl gold-ring p-3.5">
                  <f.icon size={26} className="text-goldbright" />
                </div>
                <p className="text-xs font-bold tracking-widest text-jade">{f.step}</p>
                <h3 className="font-display mt-2 text-2xl font-bold text-ivory">{f.title}</h3>
                <p className="mt-3 text-sm leading-8 text-ash">{f.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─────────────── أسئلة مقترحة ─────────────── */}
      <section className="mx-auto max-w-4xl px-4 pb-24 sm:px-6">
        <Reveal className="text-center">
          <Gauge size={18} className="mx-auto text-jade" />
          <h2 className="font-display mt-3 text-3xl font-bold text-ivory sm:text-4xl">
            جرّب أحد هذه الأسئلة
          </h2>
          <p className="mt-3 text-sm text-ash">
            اضغط على أي سؤال لتسأله مباشرة للذكاء الاصطناعي
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          {SUGGESTED.map((q, i) => (
            <Reveal key={q} delay={i * 0.06}>
              <Link
                href={`/ask?q=${encodeURIComponent(q)}`}
                className="group flex items-center justify-between gap-3 rounded-2xl glass px-5 py-4 text-sm text-sand transition-all hover:border-gold/35 hover:bg-white/6 hover:text-ivory"
              >
                <span className="flex items-center gap-3">
                  <Sparkles size={15} className="shrink-0 text-gold" />
                  {q}
                </span>
                <ArrowLeft
                  size={15}
                  className="shrink-0 text-ash transition-all group-hover:-translate-x-1 group-hover:text-goldbright"
                />
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─────────────── بطاقة القناة ─────────────── */}
      <section className="mx-auto max-w-5xl px-4 pb-8 sm:px-6">
        <Reveal>
          <div className="gold-ring relative overflow-hidden rounded-[2rem] px-8 py-12 text-center sm:px-14">
            <div className="pattern-geo absolute inset-0 opacity-40" />
            <div className="relative">
              <YoutubeIcon size={30} className="mx-auto text-goldbright" />
              <h2 className="font-display mt-4 text-3xl font-bold text-ivory sm:text-4xl">
                المصدر الوحيد للمعرفة: قناة «{CHANNEL.name}»
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-sand">
                لا يخترع «مسلم وبس» أجوبةً من فراغ — بل يسترجع النصوص الحرفية من تفريغات
                فيديوهات القناة ويعرضها لك مع روابطها، فتقرأ كلام الشيخ ثم تشاهد الفيديو بنفسك.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <a
                  href={CHANNEL.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-full bg-gradient-to-l from-golddeep via-gold to-goldbright px-6 py-3 text-sm font-bold text-night transition-transform hover:scale-105"
                >
                  <YoutubeIcon size={16} />
                  زيارة القناة على يوتيوب
                </a>
                <Link
                  href="/ask"
                  className="rounded-full glass-strong px-6 py-3 text-sm font-semibold text-ivory transition-transform hover:scale-105"
                >
                  اطرح سؤالك الآن
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
