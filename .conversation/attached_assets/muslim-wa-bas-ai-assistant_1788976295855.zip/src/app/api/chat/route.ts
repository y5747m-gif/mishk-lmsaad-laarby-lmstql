import { NextRequest } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { answerQuestion } from "@/lib/ai/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => null)) as {
      message?: string;
      conversationId?: number | null;
    } | null;

    const message = body?.message?.trim();
    if (!message || message.length < 2) {
      return Response.json(
        { ok: false, error: "اكتب سؤالًا أولًا (حرفان على الأقل)." },
        { status: 400 },
      );
    }
    if (message.length > 600) {
      return Response.json(
        { ok: false, error: "السؤال طويل جدًا (الحد الأقصى ٦٠٠ حرف)." },
        { status: 400 },
      );
    }

    // ١) المحادثة: أنشئ جديدة أو استخدم الممرّرة
    let conversationId = body?.conversationId ?? null;
    if (!conversationId) {
      const title = message.slice(0, 60);
      const [conv] = await db
        .insert(conversations)
        .values({ title })
        .returning({ id: conversations.id });
      conversationId = conv.id;
    }

    // ٢) سجّل سؤال المستخدم
    await db.insert(messages).values({
      conversationId,
      role: "user",
      content: message,
    });

    // ٣) شغّل محرك الإجابة
    const result = await answerQuestion(message);

    // ٤) سجّل جواب المساعد مع المصادر
    await db.insert(messages).values({
      conversationId,
      role: "assistant",
      content: result.answer,
      sources: result.sources,
    });

    return Response.json({
      ok: true,
      conversationId,
      kind: result.kind,
      answer: result.answer,
      sources: result.sources,
      confidence: result.confidence,
      matchedVideos: result.matchedVideos,
      debug: result.debug ?? null,
    });
  } catch (e) {
    console.error("[/api/chat]", e);
    return Response.json(
      { ok: false, error: "حدث خطأ أثناء توليد الإجابة، حاول مرة أخرى." },
      { status: 500 },
    );
  }
}
