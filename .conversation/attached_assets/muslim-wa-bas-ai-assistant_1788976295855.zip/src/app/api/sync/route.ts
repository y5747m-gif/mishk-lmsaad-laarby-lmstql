import { NextRequest } from "next/server";
import { syncChannel } from "@/lib/youtube";
import { bustIndex } from "@/lib/ai/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** تشغيل مزامنة القناة يدويًا — POST أو GET?force=1 */
export async function POST(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const force = searchParams.get("force") === "1";
    const report = await syncChannel(force);
    bustIndex();
    return Response.json(report);
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 500 },
    );
  }
}

export async function GET(req: NextRequest) {
  return POST(req);
}
