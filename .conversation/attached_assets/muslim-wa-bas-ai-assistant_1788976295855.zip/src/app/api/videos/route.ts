import { NextRequest } from "next/server";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { videos, chunks } from "@/db/schema";
import { ensureSynced } from "@/lib/youtube";
import { tokenize, normalizeArabic } from "@/lib/ai/arabic";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    await ensureSynced();
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() ?? "";

    const rows = await db
      .select({
        videoId: videos.videoId,
        title: videos.title,
        description: videos.description,
        url: videos.url,
        thumbnail: videos.thumbnail,
        publishedAt: videos.publishedAt,
        views: videos.views,
        hasTranscript: videos.hasTranscript,
        wordCount: videos.wordCount,
        syncedAt: videos.syncedAt,
        transcript: videos.transcript,
      })
      .from(videos)
      .orderBy(desc(videos.publishedAt));

    const chunkCounts = await db
      .select({
        videoId: chunks.videoId,
        count: sql<number>`count(*)::int`,
      })
      .from(chunks)
      .groupBy(chunks.videoId);
    const countMap = new Map(chunkCounts.map((c) => [c.videoId, c.count]));

    let list = rows.map((v) => ({
      ...v,
      chunks: countMap.get(v.videoId) ?? 0,
    }));

    if (q) {
      const needles = tokenize(q);
      const norm = normalizeArabic(q);
      list = list.filter((v) => {
        const hay = normalizeArabic(
          `${v.title} ${v.description} ${v.transcript ?? ""}`,
        );
        return hay.includes(norm) || needles.some((n) => hay.includes(n));
      });
    }

    // لا نُرسل النص الكامل للعميل — يكفي البيانات الوصفية
    const videosOut = list.map(({ transcript, ...rest }) => {
      void transcript;
      return rest;
    });

    return Response.json({ ok: true, total: videosOut.length, videos: videosOut });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 500 },
    );
  }
}
