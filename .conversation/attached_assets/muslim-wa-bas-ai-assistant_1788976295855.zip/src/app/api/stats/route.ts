import { sql } from "drizzle-orm";
import { db } from "@/db";
import { videos, chunks, conversations, CHANNEL } from "@/db/schema";
import { ensureSynced, getLastSync } from "@/lib/youtube";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSynced();
    const [v] = await db
      .select({
        total: sql<number>`count(*)::int`,
        transcribed: sql<number>`count(*) filter (where ${videos.hasTranscript})::int`,
        words: sql<number>`coalesce(sum(${videos.wordCount}), 0)::int`,
      })
      .from(videos);
    const [c] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(chunks);
    const [convs] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(conversations);
    const lastSync = await getLastSync();

    return Response.json({
      ok: true,
      channel: CHANNEL,
      videos: v?.total ?? 0,
      transcribed: v?.transcribed ?? 0,
      words: v?.words ?? 0,
      chunks: c?.total ?? 0,
      conversations: convs?.total ?? 0,
      lastSync: lastSync ? lastSync.toISOString() : null,
    });
  } catch (e) {
    return Response.json({
      ok: false,
      channel: CHANNEL,
      videos: 0,
      transcribed: 0,
      words: 0,
      chunks: 0,
      conversations: 0,
      lastSync: null,
      error: e instanceof Error ? e.message : String(e),
    });
  }
}
